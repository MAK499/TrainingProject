package com.pack.exception;

import java.util.Arrays;

public class CustomException extends Exception

{

	/*@Override
	public String toString() {
		return "Error Occured";
	}*/

}
